# Codebook: awareness_survey_deidentified.csv

One row per submitted questionnaire (973 rows). Column names are the questionnaire items as they appeared on the form; short names used in the analysis code are given in brackets.

| # | Column (short name) | Values |
|---|---|---|
| 1 | Timestamp (`timestamp`) | Date of submission (time of day removed). Pilot phase October to November 2025; main phase September to October 2026 |
| 2 | Enumerator code (`collector_raw`) | Anonymous code of the student enumerator (C001 to C288). In 49 pilot responses an earlier form version stored the respondent's age group here; the analysis moves it to the age column. Blank when no valid code was recorded |
| 3 | Age Group (`age`) | Below 20; 20-29; 30-39; 40-49; 50 and above (the form recorded the bands with a dash; the analysis recodes them as "20 to 29" and so on) |
| 4 | Gender (`gender`) | Male; Female; Prefer not to say |
| 5 | Highest Educational Level (`education`) | No formal education; Primary; Secondary; Tertiary; Postgraduate |
| 6 | Occupation (`occupation`) | Student; Trader / Businessperson; Civil servant; Healthcare worker; Retired; Others |
| 7 | Place of Residence (`residence`) | Urban area; Semi-urban area; Rural area |
| 8 | Have you ever heard about Alzheimer's disease? (`heard`) | Yes; No |
| 9 | If yes, where did you first hear about it? (`source`) | Multiple choice separated by semicolons: Social media; TV / Radio; Hospital / Health center; Family or friends; School / Seminar; Others |
| 10 | Current understanding of Alzheimer's disease (`understanding`) | 1 (very low) to 5 (very high) |
| 11 | Is Alzheimer's disease a normal part of aging? (`normal_ageing`) | Yes; No; Not sure |
| 12 | Knows someone with symptoms (`know_someone`) | Yes; No; Not sure |
| 13 | Community view of Alzheimer's disease (`community_view`) | As a medical condition; As a normal aging problem; As a spiritual or traditional issue; I don't know |
| 14 | Memory loss discussed openly (`open_talk`) | Yes; Sometimes; No |
| 15 | Usual community response to symptoms (`usual_response`) | Taken to hospital; Taken for traditional healing; Ignored / considered normal; I don't know |
| 16 | Cultural beliefs affect early detection (`culture_affects`) | 1 (not at all) to 5 (strongly) |
| 17 | Frequency of health-centre visits (`checkups`) | Regularly; Once or twice a year; Occasionally; Never |
| 18 | Ease of getting health information (`info_ease`) | Very easy; Somewhat easy; Difficult; Very difficul (sic, harmonised to "Very difficult" in the analysis) |
| 19 | Internet or smartphone access for health education (`internet`) | Yes; No |
| 20 | Interest in digital awareness programmes (`digital_interest`) | Yes; Maybe; No |
| 21 | Biggest reason for low awareness (`reason_text`) | Free text |
| 22 | Suggestions for improving awareness (`suggestion_text`) | Free text |

Cleaning applied in `analysis_awareness.py`: recovery of age group for the 49 pilot responses, removal of 4 exact duplicates and 1 response with missing core items (analytic sample 968), and harmonisation of the response option "Very difficul".
